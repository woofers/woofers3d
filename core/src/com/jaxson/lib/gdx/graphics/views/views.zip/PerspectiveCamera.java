package com.jaxson.lib.gdx.graphics.views;

import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;

public class PerspectiveCamera implements Camera
{
	private com.badlogic.gdx.graphics.PerspectiveCamera camera;

	public PerspectiveCamera(float fieldOfViewY, float viewportWidth, float viewportHeight)
	{
		this(new com.badlogic.gdx.graphics.PerspectiveCamera(fieldOfViewY, viewportWidth, viewportHeight));
	}

	public void update(float dt)
	{
		camera.update();
	}

	public void update(float dt, boolean updateFrustum)
	{
		camera.update(updateFrustum);
	}
}
