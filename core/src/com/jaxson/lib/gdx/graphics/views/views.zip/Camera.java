package com.jaxson.lib.gdx.graphics.views;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Graphics;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Frustum;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Quaternion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.Ray;

public interface Camera
{
	public void update(float dt);

	public void update(float dt, boolean updateFrustum);

	public void lookAt(float x, float y, float z);

	public void lookAt(Vector3 target);

	public void normalizeUp();

	public void rotate(float angle, float axisX, float axisY, float axisZ);

	public void rotate(Vector3 axis, float angle);

	public void rotate(final Matrix4 transform);

	public void rotate(final Quaternion quat);

	public void rotateAround(Vector3 point, Vector3 axis, float angle);

	public void transform(final Matrix4 transform);

	public void translate(float x, float y, float z);

	public void translate(Vector3 vec);

	public Vector3 unproject(Vector3 screenCoords,
			float viewportX, float viewportY,
			float viewportWidth, float viewportHeight);

	public Vector3 unproject(Vector3 screenCoords);

	public Vector3 project(Vector3 worldCoords);

	public Vector3 project(Vector3 worldCoords,
			float viewportX, float viewportY,
			float viewportWidth, float viewportHeight);

	public Ray getPickRay(float screenX, float screenY,
				float viewportX, float viewportY,
				float viewportWidth, float viewportHeight);

	public Ray getPickRay(float screenX, float screenY);
}
