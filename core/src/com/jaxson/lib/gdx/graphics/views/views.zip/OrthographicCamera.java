package com.jaxson.lib.gdx.graphics.views;

import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;

public class OrthographicCamera implements Camera
{
	private com.badlogic.gdx.graphics.OrthographicCamera camera;

	public OrthographicCamera()
	{
		this(new com.badlogic.gdx.graphics.OrthographicCamera());
	}

	public OrthographicCamera (float viewportWidth, float viewportHeight) {
		this(new com.badlogic.gdx.graphics.OrthographicCamera(viewportWidth, viewportHeight));
	}

	private OrthographicCamera(com.badlogic.gdx.graphics.OrthographicCamera camera)
	{
		this.camera = camera;
	}

	public void update(float dt)
	{
		camera.update();
	}

	public void update(float dt, boolean updateFrustum)
	{
		camera.update(updateFrustum);
	}

	public void setToOrtho(boolean yDown)
	{
		camera.setToOrtho(yDown);
	}

	public void setToOrtho(boolean yDown, float viewportWidth, float viewportHeight)
	{
		camera.setToOrtho(yDown, viewportWidth, viewportHeight);
	}

	public void rotate(float angle)
	{
		camera.rotate(angle);
	}

	public void translate(float x, float y)
	{
		camera.translate(x, y);
	}

	public void translate(Vector2 vec)
	{
		camera.translate(vec);
	}
}
